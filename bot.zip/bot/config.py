# config.py

# Токен вашего Telegram-бота
TOKEN = '7797487743:AAH5BUOV-SY0Wuws5-LrArfXt5GjtXQppuI'  # Замените на ваш токен, полученный у @BotFather

# Настройки базы данных
DATABASE_NAME = 'database.db'  # Имя файла базы данных
